use cargomon;

fn main() {
    cargomon::run();
}
